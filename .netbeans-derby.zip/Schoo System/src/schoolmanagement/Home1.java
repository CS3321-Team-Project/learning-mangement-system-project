/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package schoolmanagement;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author anh
 */
public class Home1 extends javax.swing.JFrame {

    /**
     * Creates new form Home1
     */
     public Home1() {
        setLocationRelativeTo(null);
        initComponents();
     
        
        date();
        getdata();
        getdata1();
        chk();
       
        
        
    }
     String host = "jdbc:derby://localhost:1527/SchoolManagement;create=true";
       

        String username="school";
        String password="school";
 private void getdata()
    {
        
        try
        {
            
           Connection con= DriverManager.getConnection(host,username,password);
           Statement stmt= con.createStatement();
           String query="select count(id) as count from login where type = 'student' ";
         
           ResultSet rs=stmt.executeQuery(query);
          
           while(rs.next())
           {
                
                totals.setText(rs.getString("count"));
              
           
           
        }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Error"+e);
        }
    
    }
 private void getdata1()
    {
        
        try
        {
            
           Connection con= DriverManager.getConnection(host,username,password);
           Statement stmt= con.createStatement();
           
           String query1="select count(id) as count1 from class  ";
          
           ResultSet rs1=stmt.executeQuery(query1);
           while(rs1.next())
           {
                
            
                totalc.setText(rs1.getString("count1"));
           
           
        }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Error"+e);
        }
    
    }
        
     void date(){
        Date d = new Date();
        SimpleDateFormat s = new SimpleDateFormat("MM-dd-yyyy");
        showdate.setText(s.format(d));
     }

    private void chk()
    {
        Login lg = new Login();
        lbl_name.setText(lg.name);
        lbl_type.setText(lg.type);
       
        if(lg.type.equals("student"))
        {
            
                   create_user.setVisible(false);
                   create_class.setVisible(false);
                   grade_student.setVisible(false);
                   totalc.setVisible(false);
                   totals.setVisible(false);
                   lbl_tts.setVisible(false);
                   lbl_ttc.setVisible(false);
                   
        }
         if(lg.type.equals("admin"))
        {
            
                   enrollment.setVisible(false);
                   score.setVisible(false);
                   schedule.setVisible(false);
                   dropclass.setVisible(false);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        create_user = new javax.swing.JButton();
        create_class = new javax.swing.JButton();
        grade_student = new javax.swing.JButton();
        enrollment = new javax.swing.JButton();
        schedule = new javax.swing.JButton();
        score = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        totalc = new javax.swing.JLabel();
        lbl_ttc = new javax.swing.JLabel();
        lbl_tts = new javax.swing.JLabel();
        totals = new javax.swing.JLabel();
        showdate = new javax.swing.JLabel();
        lbl_type = new javax.swing.JLabel();
        lbl_name = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        dropclass = new javax.swing.JButton();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximizedBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setMinimumSize(new java.awt.Dimension(930, 530));
        getContentPane().setLayout(null);

        create_user.setBackground(new java.awt.Color(153, 0, 0));
        create_user.setText("Create Student Account");
        create_user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_userActionPerformed(evt);
            }
        });
        getContentPane().add(create_user);
        create_user.setBounds(330, 50, 160, 23);

        create_class.setBackground(new java.awt.Color(255, 102, 102));
        create_class.setText("Create Courses");
        create_class.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_classActionPerformed(evt);
            }
        });
        getContentPane().add(create_class);
        create_class.setBounds(330, 130, 160, 23);

        grade_student.setBackground(new java.awt.Color(255, 204, 204));
        grade_student.setText("Grade Student");
        grade_student.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                grade_studentActionPerformed(evt);
            }
        });
        getContentPane().add(grade_student);
        grade_student.setBounds(330, 220, 160, 23);

        enrollment.setBackground(new java.awt.Color(204, 204, 0));
        enrollment.setText("Add Courses");
        enrollment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enrollmentActionPerformed(evt);
            }
        });
        getContentPane().add(enrollment);
        enrollment.setBounds(330, 90, 160, 23);

        schedule.setBackground(new java.awt.Color(255, 255, 51));
        schedule.setText("View Schedule");
        schedule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                scheduleActionPerformed(evt);
            }
        });
        getContentPane().add(schedule);
        schedule.setBounds(330, 170, 160, 23);

        score.setBackground(new java.awt.Color(102, 255, 102));
        score.setText("View Score ");
        score.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                scoreActionPerformed(evt);
            }
        });
        getContentPane().add(score);
        score.setBounds(330, 350, 160, 23);

        jButton1.setBackground(new java.awt.Color(255, 51, 102));
        jButton1.setText("Exit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(700, 353, 70, 30);

        totalc.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        getContentPane().add(totalc);
        totalc.setBounds(700, 200, 60, 30);

        lbl_ttc.setFont(new java.awt.Font("Leelawadee UI", 1, 12)); // NOI18N
        lbl_ttc.setText("Total Course:");
        getContentPane().add(lbl_ttc);
        lbl_ttc.setBounds(600, 200, 80, 30);

        lbl_tts.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 14)); // NOI18N
        lbl_tts.setText("Total Student:");
        getContentPane().add(lbl_tts);
        lbl_tts.setBounds(600, 140, 80, 30);

        totals.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        getContentPane().add(totals);
        totals.setBounds(700, 140, 60, 30);

        showdate.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 18)); // NOI18N
        getContentPane().add(showdate);
        showdate.setBounds(720, 20, 170, 40);

        lbl_type.setFont(new java.awt.Font("Yu Gothic UI Semilight", 1, 14)); // NOI18N
        getContentPane().add(lbl_type);
        lbl_type.setBounds(100, 30, 60, 20);

        lbl_name.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        getContentPane().add(lbl_name);
        lbl_name.setBounds(160, 20, 90, 40);

        jLabel1.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        jLabel1.setText("Welcome");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(10, 24, 90, 30);

        dropclass.setBackground(new java.awt.Color(204, 255, 102));
        dropclass.setText("Drop Class");
        dropclass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dropclassActionPerformed(evt);
            }
        });
        getContentPane().add(dropclass);
        dropclass.setBounds(330, 270, 160, 23);

        background.setIcon(new javax.swing.ImageIcon("C:\\Users\\anh\\Documents\\NetBeansProjects\\Schoo System\\pics\\108871040-modern-abstract-network-science-connection-technology-internet-and-graphic-design-on-hi-tech-future-.jpg")); // NOI18N
        background.setText("jLabel1");
        getContentPane().add(background);
        background.setBounds(0, 0, 940, 490);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void create_userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_userActionPerformed
        // TODO add your handling code here:
        createuser cu;
        cu = new createuser();
      
        cu.setVisible(true);
    }//GEN-LAST:event_create_userActionPerformed

    private void create_classActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_classActionPerformed
        // TODO add your handling code here:
         createclass cc;
        cc = new createclass();
      
        cc.setVisible(true);
    }//GEN-LAST:event_create_classActionPerformed

    private void enrollmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enrollmentActionPerformed
        // TODO add your handling code here:
        enrollment cc;
        cc = new enrollment();
      
        cc.setVisible(true);
    }//GEN-LAST:event_enrollmentActionPerformed

    private void scheduleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scheduleActionPerformed
        // TODO add your handling code here:
        schedule cc;
        cc = new schedule();
      
        cc.setVisible(true);
    }//GEN-LAST:event_scheduleActionPerformed

    private void grade_studentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_grade_studentActionPerformed
        // TODO add your handling code here:
         grade cc;
        cc = new grade();
      
        cc.setVisible(true);
    }//GEN-LAST:event_grade_studentActionPerformed

    private void scoreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scoreActionPerformed
        // TODO add your handling code here:
        score cc;
        cc = new score();
      
        cc.setVisible(true);
    }//GEN-LAST:event_scoreActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void dropclassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dropclassActionPerformed
        // TODO add your handling code here:
        dropclass dc;
        dc= new dropclass();
      
        dc.setVisible(true);
    }//GEN-LAST:event_dropclassActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel background;
    private javax.swing.JButton create_class;
    private javax.swing.JButton create_user;
    private javax.swing.JButton dropclass;
    private javax.swing.JButton enrollment;
    private javax.swing.JButton grade_student;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lbl_name;
    private javax.swing.JLabel lbl_ttc;
    private javax.swing.JLabel lbl_tts;
    private javax.swing.JLabel lbl_type;
    private javax.swing.JButton schedule;
    private javax.swing.JButton score;
    private javax.swing.JLabel showdate;
    private javax.swing.JLabel totalc;
    private javax.swing.JLabel totals;
    // End of variables declaration//GEN-END:variables
}
